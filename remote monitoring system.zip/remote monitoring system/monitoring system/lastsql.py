import mysql.connector
import json
import os

 
# def sql_pid(file1):
# file1='/home/sois/Desktop/try/Views/172.16.51.25pid.json'
# print(file1)
# json_data= open(file1).read()
# json_obj = json.loads(json_data)
# do validation and checks before insert

dirName = '/home/sois/Desktop/try/Views/'
directory_names = os.listdir(dirName)

def initial_setup():

    for directory in directory_names:
        host_name = directory

        files_names_list = os.listdir(os.path.join(dirName, directory))

        directory_path = os.path.join(dirName, directory)

        for files in files_names_list:
            json_data = open(os.path.join(directory_path,files)).read()
            json_obj = json.loads(json_data)
            if "pid" in files:
                write_pid_to_db(json_obj, host_name)
            elif "memory" in files:
                write_memory_to_db(json_obj, host_name)
            elif "cpuInfo" in files:
                write_cpu_to_db(json_obj, host_name)


def validate_string(val):

    if val != None:
        if type(val) is int:
            #for x in val:
            #   print(x)
            return str(val).encode('utf-8')
        else:
            return val

def write_pid_to_db(json_obj, host):

    print("started writing to db")
    db =  mysql.connector.connect(host="localhost",database="project",user="root", passwd="")
    cursor = db.cursor()
    print("hi")
    for i, item in enumerate(json_obj):
           #host = validate_string(item.get("host", None))
        user = validate_string(str(obj['user']))
        pid = validate_string(str(obj['pid']))
        cpu_percentage= validate_string(str(obj['cpu_percentage']))
        memory_percentage= validate_string(str(obj['memory_percentage']))
        time= validate_string(str(obj['time']))
        command= validate_string(str(obj['command']))
    cursor.execute("INSERT INTO pid_info(host,user,pid,cpu_percentage,memory_percentage,time,command) VALUES (%s,%s,%s,%s,%s,%s,%s)",(host,user,pid,cpu_percentage,memory_percentage,time,command))
    print("done")
    db.commit()
    db.close()

def write_memory_to_db(json_obj, host):
    print("started writing to db")
    db =  mysql.connector.connect(host="localhost",database="project",user="root", passwd="")
    cursor = db.cursor()
    print("hi")
    for i, item in enumerate(json_obj):
           
        
        total = validate_string(str(obj['total']))
        used= validate_string(item.get("used", None))
        available= validate_string(item.get("available", None))
        free= validate_string(item.get("free", None))
        active= validate_string(item.get("active", None))
        inactive= validate_string(item.get("inactive", None))
        buffers= validate_string(item.get("buffers", None))
        cached= validate_string(item.get("cached", None))
        slab= validate_string(item.get("slab", None))
    cursor.execute("INSERT INTO memory_info(host,total,used,available,free,active,inactive,buffers,cached,slab) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(host,total,used,available,free,active,inactive,buffers,cached,slab))
    print("done")
    db.commit()
    db.close()

def write_cpu_to_db(json_obj, host):
    print("started writing to db")
    db =  mysql.connector.connect(host="localhost",database="project",user="root", passwd="")
    cursor = db.cursor()
    print("hi")
    for i, item in enumerate(json_obj):
        print("start")
           
        #cpu_family =validate_string(item.get("cpu_family", None))
        threads_per_core= validate_string(item.get("threads_per_core", None))
        core_per_socket= validate_string(item.get("core_per_socket", None))
        
        cpu_mhz= validate_string(item.get("cpu_mhz", None))
        virtualization_type= validate_string(item.get("virtualization_type", None))
    cursor.execute("INSERT INTO cpu_info(host,cpu_family,threads_per_core,core_per_socket,cpu_mhz,virtualization_type) VALUES (%s,%s,%s,%s,%s,%s)",(host,cpu_family,threads_per_core,core_per_socket,cpu_mhz,virtualization_type))
    print("done")
    db.commit()
    db.close()


# fileNames = [f for f in listdir(dirName) if isfile(join(dirName, f))]
# # print(fileNames)
# for file in fileNames:
#     if ("pid.json"==file[12:]):
      
#         # sql_pid("file")
#     # elif ("cpuInfo.json"==file[12:]):
#     #     sqlcpuinfo(file)
#     # elif ("memory.json"==file[12:]):
#     #     sqlmemory(file)
#         path=os.path.abspath(file)
#         # print(path)
#         sql_pid(path)
#     else:
#         continue



    
