def ip_scanner()
    import subprocess 

    host=[]
    for ping in range(1,100): 
        address = "172.16.51." + str(ping) 
        res = subprocess.call(['ping', '-c', '3', address]) 

        
        if res == 0: 
            # print( "ping to", address, "OK") 
            host.append(address)

        elif res == 2: 
            # print("no response from", address) 
            continue
        else: 
            # print("ping to", address, "failed!")
            continue 
    return(host)
