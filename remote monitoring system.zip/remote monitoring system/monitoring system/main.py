import pid
import memory
import getpass
import sensors
import network
import cpu_info
import disk
import SystemInfo
import os
import sqlconn
#import ipscanner



# def file_read():
#     file = open('/home/sois/Desktop/monitoring system/hostlist.txt')
#     file_content = file.readlines()
#     host_list = [];

#     for row in file_content:
        
#         host_list = row.split(",");
#     file.close()
#     return (host_list)

def file_read():
    file = open('/home/sois/Desktop/monitoring system/hostlist.txt')
    host_list = [];

    for line in file.readlines():
    	host_list.append(line)
    return host_list




def job(json_path):
    print("Process Started")
    memory.sshConnectMemory(host, username, password, json_path)
    pid.sshConnectPid(host, username, password, json_path)
    sensors.sshConnectSensors(host, username, password, json_path)
    network.sshConnectNetwork(host, username, password, json_path)
    cpu_info.sshConnectCPU_Info(host, username, password, json_path)
    disk.sshConnectDisk(host, username, password, json_path)
    SystemInfo.sshConnectSysInfo(host, username, password, json_path)


if __name__ == "__main__":
    
    #scanning of the ip Address
    #host_list = ipscanner.ip_scanner()
    #reading the ip address from the text file
    host_list=file_read()

    for i in host_list:
        if not os.path.exists(os.path.join("./Views", i)):
            os.mkdir(os.path.join("./Views", i))
        #host = input("enter the host name or IP address\n")
        host = i
        #username = input("enter the username\n")
        username = "sois"

        password = getpass.getpass(prompt='Password: ', stream=None)
       
        # json_Path = "./Views/host"
        absolute_path = os.path.abspath(".")
        print(absolute_path)
        folder_path = os.path.join("./Views", i)
        json_Path = folder_path

        job(json_Path)

        #Read data from json file and write the values to DB
        
        sqlconn.initial_setup()
        print("data is inserted successfully")
