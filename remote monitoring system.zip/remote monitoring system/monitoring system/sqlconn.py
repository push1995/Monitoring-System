import mysql.connector
import json
import os

dirName = '/home/sois/Desktop/monitoring system/Views/'
directory_names = os.listdir(dirName)

def initial_setup():
    print("welcome")

    for directory in directory_names:
        host_name = directory

        files_names_list = os.listdir(os.path.join(dirName, directory))

        directory_path = os.path.join(dirName, directory)

        for files in files_names_list:
            json_data = open(os.path.join(directory_path,files)).read()
            json_obj = json.loads(json_data)
            if "pid" in files:
                write_pid_to_db(json_obj, host_name)
                continue
            elif "memory" in files:
                write_memory_to_db(json_obj, host_name)
            elif "cpuInfo" in files:
                write_cpu_to_db(json_obj, host_name)


def validate_string(val):

    if val != None:
        if type(val) is int:
            #for x in val:
            #   print(x)
            return str(val).encode('utf-8')
        else:
            return val

def write_pid_to_db(json_obj, host):


    print("started writing pid to db")
    db =  mysql.connector.connect(host="localhost",database="project",user="root", passwd="")
    cursor = db.cursor()

    query = ("DELETE FROM pid_info WHERE host= %s")
    cursor.execute(query, (host,))
    for i, item in enumerate(json_obj):
         
        user = validate_string(item.get("user", None))
        pid = validate_string(item.get("pid", None))
        cpu_percentage= validate_string(item.get("cpu_percentage", None))
        memory_percentage= validate_string(item.get("memory_percentage", None))
        time= validate_string(item.get("time", None))
        command= validate_string(item.get("command", None))

        cursor.execute("INSERT INTO pid_info(host,user,pid,cpu_percentage,memory_percentage,time,command) VALUES (%s,%s,%s,%s,%s,%s,%s)",(host,user,pid,cpu_percentage,memory_percentage,time,command))
        # print("done")
        db.commit()
    db.close()

def write_memory_to_db(json_obj, host):
    print("started writing memory to db")
    db =  mysql.connector.connect(host="localhost",database="project",user="root", passwd="")
    cursor = db.cursor()
    # print("hi")
    for item in (json_obj):

        total = validate_string(json_obj["virtual"]["total"])
        used = validate_string(json_obj["virtual"]["used"])
        available = validate_string(json_obj["virtual"]["available"])
        free = validate_string(json_obj["virtual"]["free"])
        active = validate_string(json_obj["virtual"]["active"])
        inactive = validate_string(json_obj["virtual"]["inactive"])
        buffers = validate_string(json_obj["virtual"]["buffers"])
        cached = validate_string(json_obj["virtual"]["cached"])
        slab = validate_string(json_obj["virtual"]["slab"])
    query = ("DELETE FROM memory_info WHERE host= %s")
    cursor.execute(query, (host,))
    cursor.execute("INSERT INTO memory_info(host,total,used,available,free,active,inactive,buffers,cached,slab) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(host,total,used,available,free,active,inactive,buffers,cached,slab))
    print("done")
    db.commit()
    db.close()

def write_cpu_to_db(json_obj, host):
    print("started writing cpu info to db")
    db =  mysql.connector.connect(host="localhost",database="project",user="root", passwd="")
    cursor = db.cursor()
    for item in (json_obj):

        architecture = (json_obj["architecture"])
        threads_per_core = (json_obj.get("threads_per_core", None))
        core_per_socket = (json_obj.get("core_per_socket", None))

        sockets = (json_obj.get("sockets", None))
    query = ("DELETE FROM cpu_info WHERE host= %s")
    cursor.execute(query, (host,))
    cursor.execute("INSERT INTO cpu_info(host,threads_per_core,core_per_socket,sockets,architecture) VALUES (%s,%s,%s,%s,%s)",(host,threads_per_core,core_per_socket,sockets,architecture))
    db.commit()
    db.close()






    
