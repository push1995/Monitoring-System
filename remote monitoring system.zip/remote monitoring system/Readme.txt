﻿1. Monitoring system folder contains the project complete code  in that we have to execute main.py file

2. Report and ppt folder contains report and ppt(both docx and pdf)

3. References folder contains the references
 
4. output snapshot  file contains snapshots of the project




PROEJCT TEAM MEMBER DETAILS :


NAME
AISIRI CS 
BRANCH
CLOUD COMPUTING
REGISTRATION NUMBER
191047001
MOBILE NUMBER
8197635776
EMAIL ID
aisiri.cs@gmail.com

NAME
PUSHPA G
BRANCH
CLOUD COMPUTING
REGISTRATION NUMBER
91047015
MOBILE NUMBER
9611914947
EMAIL ID
pushpayuvi95@gmail.com

NAME
RAKSHITHA R
BRANCH
CLOUD COMPUTING
REGISTRATION NUMBER
191047013
MOBILE NUMBER
8550830996
EMAIL ID
rakshividya1997@gmail.com

